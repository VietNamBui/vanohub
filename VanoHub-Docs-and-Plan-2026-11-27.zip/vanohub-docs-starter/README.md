# VanoHub documentation package

Prepared: 2026-11-27, Asia/Ho_Chi_Minh.

This package contains nine populated repository documents and an additive Git patch. It supports the ongoing local refactor, using the conversation, attached notes, and pinned GitHub sources. It does not contain an application rewrite or a copy of the existing product specification.

Start with [the implementation plan](docs/refactoring/plan.md) and [the documentation index](docs/refactoring/README.md).

## Included repository files

| File | Purpose |
| --- | --- |
| [docs/refactoring/README.md](docs/refactoring/README.md) | Navigation, document authority, adoption instruction |
| [docs/refactoring/plan.md](docs/refactoring/plan.md) | T00–T09 tasks, dependencies, acceptance, first local handoff |
| [docs/refactoring/baseline.md](docs/refactoring/baseline.md) | Pinned remote observations, provenance, local baseline fields |
| [docs/refactoring/decisions.md](docs/refactoring/decisions.md) | Six cross-cutting decisions with consequences and acceptance |
| [docs/refactoring/agent-workflow.md](docs/refactoring/agent-workflow.md) | Neon/Hydrogen roles, MCP retrieval, ownership, compact handoffs |
| [docs/refactoring/changes.md](docs/refactoring/changes.md) | Initialization record and reusable logical-change template |
| [docs/api/contracts.md](docs/api/contracts.md) | Observed API surfaces, proposed extensions, schema and compatibility procedure |
| [docs/ui/verification.md](docs/ui/verification.md) | Screen/role/state checks and evidence format |
| [docs/operations/security-and-verification.md](docs/operations/security-and-verification.md) | Transport rules, integration boundaries, required verification |

The package also contains `docs.patch` for those nine files and `SHA256SUMS` for integrity checks. Existing `AGENTS.md`, `ARCHITECTURE.md`, `docs/platform-spec.md`, and `docs/mvp-checklist.md` remain in their repository.

## Apply to the active local checkout

Extract the ZIP outside the repository. Set both paths below to their real absolute locations. Check the local agent's active files before adoption.

~~~bash
repo="/absolute/path/to/vanohub"
package="/absolute/path/to/vanohub-docs-starter"

git -C "$repo" status --short
git -C "$repo" apply --stat "$package/docs.patch"
git -C "$repo" apply --check "$package/docs.patch" &&
  git -C "$repo" apply "$package/docs.patch"
git -C "$repo" status --short -- docs
~~~

The patch adds files. If a target already exists, stop and reconcile that document with its newer local contents; do not force the patch or replace the local file blindly. The new files remain uncommitted. The patch does not modify root instructions, application code, dependencies, migrations, or runtime configuration.

After adoption, merge the short link paragraph from [the documentation index](docs/refactoring/README.md) into the existing `AGENTS.md`. Then give the local orchestrator T00. It should capture the actual worktree, account for changes already completed, and choose the next bounded task.

## Initial implementation status

- Documentation package: authored.
- Remote branch heads and selected source: inspected at the revisions recorded in the baseline.
- Active local refactor, local MCP index, and deployed CVAT: not inspected from this session.
- Application changes, tests, migrations, or deployment: not performed by this package.
- Proposed telemetry and API extensions: design work only, not implemented routes.

The existing source and the attached notes disagree in places. Those differences are preserved as explicit decisions rather than treated as settled requirements. Numerical progress claims in the old checklist are not reused as current status.

## Package verification

- Passed: 63 internal document links resolve.
- Passed: task IDs T00–T09 and decision IDs D01–D06 are unique and complete.
- Passed: the nine-file patch passes Git's applicability/whitespace check and reconstructs the authored files byte for byte in an isolated test repository.
- Passed: an existing-target collision is rejected and unrelated local instructions are preserved.
- Passed: the final ZIP passes integrity and member/checksum verification.
- Not run: application tests, migrations, browser checks, or deployment checks.

These package checks do not establish application correctness. To check the extracted package locally:

~~~bash
cd "$package"
sha256sum --check SHA256SUMS
~~~

## Maintenance

Keep full business rules in the existing product specification, exact changes in Git, API shapes in the selected canonical schema workflow, and a compact explanation/evidence entry in the change log. Update documents only when their facts change. No per-tool diary, repeated whole-repository summary, or fixed token-saving promise is required.
