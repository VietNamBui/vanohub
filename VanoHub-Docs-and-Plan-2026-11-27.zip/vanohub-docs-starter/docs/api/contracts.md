# API contracts and change procedure

Prepared: 2026-11-27. This is a populated contract inventory and implementation guide. It is not a complete generated OpenAPI description of the live local application.

## 1. Ownership and boundaries

Maintain separate surfaces:

| Surface | Authority | Documentation treatment |
| --- | --- | --- |
| VanoHub API consumed by its frontend/integrations | Active URL configuration, views/serializers, accepted behavior, and contract tests | One reproducible current OpenAPI artifact; behavioral explanations here |
| Native CVAT API consumed by VanoHub | The actual deployed CVAT version and its published schema/source | Reference or pin that schema; document adapter expectations rather than copying the whole API |
| Proposed VanoHub/CVAT/gateway extensions | Accepted requirement and a clearly labeled proposal | Keep proposed operations separate until implemented and verified |

The product specification defines intended behavior. Current code and runtime evidence establish implemented behavior. A schema disagreement is a defect to resolve, not permission to silently change either side.

Do not publish a new custom route under CVAT's existing API documentation unless the route actually exists in the selected CVAT deployment. Shared Django/DRF technology does not automatically provide shared permissions, schema tooling, or resource isolation.

## 2. Verified branch-specific starting inventory

Source: `feature/issue-logger` at `99027769c86536807d31808ff666e9a424505aea`; [URL configuration](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/backend/config/urls.py), [integration URLs](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/backend/cvat_integration/urls.py), and [views](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/backend/cvat_integration/views.py).

| Operation/surface | Observed behavior | Contract work still required locally |
| --- | --- | --- |
| `GET /api/cvat/status/` | Calls CVAT about; success body contains `connected`, `url`, `version`. Caught upstream failures return `connected: false`, `url`, `detail` without selecting an error status explicitly. | Capture current effective authentication, HTTP status, redaction, timeout, and frontend interpretation |
| `GET /api/cvat/tasks/` | View checks `user.is_pm()`; accepts `project_id` and `search`; returns a list of task summaries; caught CVAT errors map to 502 | Verify tenant/organization filtering separately from the PM check; define upstream-ID meaning, validation, list limits, and error handling |
| `/api/auth/` | Includes accounts URL configuration | Enumerate actual methods/paths from the active child routes |
| `/api/` | Includes projects, teams, jobs, quality, analytics routes | Inventory active routers/actions and their consumers; this prefix is not one endpoint |

The `project_id` query in the observed task-list view is passed to the CVAT client. Do not document it as a VanoHub project identifier without checking the adapter and local changes.

This small table is deliberately branch-specific and incomplete. T03 must capture the active API, including import/sync, claim/start/submit, QC1, batch confirmation, audits, delivery, and analytics. The PM branch has additional integration behavior; see [D01–D03](../refactoring/decisions.md).

## 3. Current schema workflow

T00 discovers the local schema generator, artifact location, validation command, and docs UI. Reuse them if they already exist. Generator changes and schema generation belong to T03, after T02 establishes the runnable baseline and any affected T01 decisions are resolved. The inspected remote URL/dependency files do not establish that such tooling is configured.

If none exists:

1. Select a generator compatible with the actual installed Django/DRF versions and existing dependency policy.
2. Generate from active routes and serializers, adding explicit schema annotations for permissions, custom actions, responses, and nontrivial errors.
3. Record the exact command, environment, output path, and source revision. A conventional target is `docs/api/openapi.yaml`; this package does not create a misleading empty schema.
4. Validate the schema and compare representative real responses/errors against it.
5. Review schema diffs alongside code. Keep frontend types or generated clients synchronized through one documented command if code generation is adopted.

For implemented operations, the generated artifact is the current machine-readable contract. Do not maintain a second full handwritten copy. For a new operation, a small contract-first proposal can guide implementation; reconcile it with generated output before marking the operation current.

Record generator/schema changes in [changes.md](../refactoring/changes.md). A docs renderer or DRF browsable API alone is not a contract-parity check.

## 4. Contract entry for every changed operation

Use this template in the task or proposal, then retain the enduring details here or in a dedicated proposal when its size warrants it:

~~~text
Contract ID / status / owner:
Source revision and related decision/task:
Provider, consumers, method, path:
Identifier meaning and tenant scope:
Authentication and required capability:
Request fields, types, bounds, null/omitted semantics:
Success status, fields, units, timestamps, pagination:
Error statuses and safe error body:
State transition, side effects, locks/concurrency:
Idempotency, retries, timeout and stale-data behavior:
Examples: valid, boundary, unauthorized, conflict/upstream failure:
Compatibility and consumer migration:
Schema source/generation and verification:
~~~

Cover behavior as well as JSON shape. A status enum change, different authorization, new default, changed unit, or automatic workflow transition is a contract change even when field names remain the same.

Adding an optional field is not automatically compatible with strict validators; adding an enum value may break exhaustive frontend handling. Reuse the application's accepted error shape instead of introducing a new envelope during an unrelated refactor.

For project-scoped endpoints, preserve the accepted project-isolation behavior and capability checks. The reference repository rules require 404 isolation outside project scope. Do not blindly copy that rule onto authentication or globally scoped operations without checking their actual contract.

## 5. Existing proposals to evaluate, not implement automatically

These paths come from [the reference specification's backlog](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/docs/platform-spec.md). They are not established live routes.

| Proposal | Purpose | Contract decisions needed |
| --- | --- | --- |
| B3: `POST /api/projects/{id}/jobs/{job_id}/plugin-findings/` | Receive suggested auto-QC findings for human review | Project/job ownership; plugin identity; finding identity/deduplication; severity/confidence; suggested/confirmed lifecycle; no automatic job transition |
| B4: `POST /api/projects/{id}/telemetry/` | Ingest a bounded event batch | Service identity and allowed source; event schema and units; user/job mapping; limits; atomic vs partial acceptance; deduplication and retry response |
| B5: `POST /api/integrations/cvat/webhook/` | Trigger sync from supported CVAT events | Actual version-specific signature/header/body rules; event identity; replay/duplicate behavior; persistence/acknowledgment; safe retry and ordering |
| Optional GET telemetry/summary extension | Expose a demonstrated gap through an API | Provider/hosting decision D04, exact path, permitted project/job scope, filters, pagination, time window, data freshness and resource budget |

A GET-only query gateway and POST ingestion/webhook endpoints are different surfaces. Choose the required direction and owner explicitly; do not use GET to trigger business mutations.

### B4 design checklist, ready for the first proposal

The reference backlog proposes event fields such as project, job, user, source, event type, occurrence time, duration, object delta, payload, and idempotency key. Their exact types and optionality remain to be decided.

- Authenticate the service and bind it to permitted projects and sources; do not trust the submitted project/source/user as authorization.
- Specify whether job/user identifiers are VanoHub or external IDs and how mappings are resolved.
- Normalize timestamp/duration semantics under D06; bound batch size and payload depth/size.
- Define the deduplication namespace and retention window. Retries of the same logical event must not increase credited counts twice.
- Define whether a duplicate returns the original outcome, and whether invalid batches fail atomically or return per-item results.
- Reject or quarantine unmapped/invalid events according to an explicit policy; do not convert failures into zero-duration records.
- State whether telemetry informs a metric, creates a suggestion, or changes business state. No implicit workflow advancement.

This checklist is a draft contract specification, not an implemented schema or a promise about current responses.

## 6. Verification and compatibility

For each changed surface, collect:

- Schema validation and representative request/response checks.
- Allowed and disallowed project/role examples, including cross-project object IDs.
- Boundary inputs, omitted/null fields, pagination/limits, and safe upstream failures.
- Retry/replay/concurrency cases when the operation can mutate or accept duplicate work.
- Frontend type, API-wrapper, form, and status-label parity.
- Migration/rollout order if an old consumer can remain active.

Use focused checks during edits and the current repository's required gates before completing the task. Store concise outcomes with revision/environment in [changes.md](../refactoring/changes.md). A generated schema alone does not verify authorization or workflow correctness.
