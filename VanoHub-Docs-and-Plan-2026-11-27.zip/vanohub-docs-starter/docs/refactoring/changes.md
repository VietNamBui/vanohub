# Logical change log

Record one concise entry for every meaningful refactoring, UI, or API unit. Explain the behavioral or structural change and why it matters. Link source, contract, decision, and verification evidence instead of copying implementation details. A unit affecting several layers gets one entry covering all impacts.

Keep implementation status separate from verification results. “Implemented” does not mean tested; a passed check establishes only what it exercised on the recorded revision. Update an existing entry as its evidence changes rather than appending every edit, retry, or tool call. Do not record private reasoning, credentials, personal data, or raw request payloads.

## 2026-11-27 — Initialize documentation package

- **Status:** Documentation package authored and checked; uninstalled. No application implementation is claimed.
- **Purpose:** Provide a small shared record for ongoing refactoring, UI behavior, API contracts, agent handoffs, and verification.
- **Before → after:** Pinned remote snapshots and attached notes are represented in a documentation package with explicit provenance, unresolved decisions, and reusable working procedures. This does not reconcile those snapshots with the user's current local checkout.
- **Scope and impact:** Documentation only. No application files were altered. No UI behavior, API route, payload, authorization rule, workflow transition, schema, or CVAT integration was implemented or changed by this initialization.
- **Compatibility:** No application compatibility claim is needed for this docs-only change. Existing `docs/platform-spec.md` remains the product authority. CVAT project-mapping and workflow-state conflicts remain evidence/decision items; this entry resolves neither. Telemetry and new API ideas remain proposals.
- **Provenance:** See the [baseline](./baseline.md) for pinned remote-source references and attached-note provenance, and [decisions](./decisions.md) for conflicts. The local branch, dirty state, runtime behavior, and MCP index freshness were not verified here. The [agent workflow](./agent-workflow.md) retains the user-reported orchestration configuration without capability claims.
- **Verification:** Internal document links resolved. The nine-file patch passed an isolated applicability/content check; an existing-target collision was rejected and an unrelated local instruction file was preserved. No application tests were run. Archive and checksum results are reported in the delivery README.
- **Reversibility:** The uninstalled package can be discarded or revised. No application migration or external-system effect was performed by this initialization.
- **Commit:** None.
- **Next:** Follow the [plan](./plan.md) to reconcile the package with the active checkout before treating observed claims as current implementation facts.

## Reusable entry

Copy this template for a logical unit; omit irrelevant subdetails, not material risks. Use the actual completion/update date and stable task identifier. Record UI label examples in Vietnamese when needed. Refer to [contracts](../api/contracts.md), [UI verification](../ui/verification.md), and [operational verification](../operations/security-and-verification.md) where applicable.

```text
## YYYY-MM-DD — ID: concise change title

- Status: proposed / in progress / implemented / blocked / documentation only.
- Purpose and before → after: problem, logical change, resulting behavior.
- Scope: owner; worktree/branch; HEAD; relevant dirty diff; changed files.
- Impacts: refactoring; UI; API; permissions/workflow; data/CVAT; consumers.
- Compatibility: preserved behavior or breaking change; rollout/deprecation;
  linked contract/decision; affected consumers and required coordination.
- Evidence: current source references and revision; distinguish historical
  evidence, proposals, and directly observed implementation.
- Verification: check/command, working directory, revision/environment,
  actual result; failed, blocked, or unrun checks and their concrete reason.
- Reversibility: code rollback; migration/data limits; external effects;
  compensating actions when rollback cannot undo effects.
- Commit: exact authorized commit hash, or none.
- Follow-up: remaining decision/check/action, owner, and completion condition.
```

Do not describe a code revert as a complete rollback when migrations, data transformations, notifications, or CVAT API writes have already taken effect. Record those limits and any verified recovery procedure. Never infer a successful application check from a documentation check or from another branch's historical test result.
