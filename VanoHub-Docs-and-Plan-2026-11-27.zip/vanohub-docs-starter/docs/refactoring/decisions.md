# Refactor decisions

Prepared: 2026-11-27. All records below are **open for local reconciliation**, not new accepted product requirements. A newer accepted decision in the local checkout can resolve a record immediately when its evidence is recorded.

Use this file for the small number of choices that cross data, API, workflow, and UI boundaries. Split an individual record into an ADR only when its size or independent lifecycle warrants it. Link to the product specification rather than duplicating its full rules.

## Decision index

| ID | Decision | Blocks only |
| --- | --- | --- |
| D01 | CVAT hierarchy and tenant identity | Related migrations, identifiers, routes, and navigation |
| D02 | QC1-to-QC2 gate and sampling unit | Related transition, audit, and review UI changes |
| D03 | Identity linking and CVAT write scope | Account migration, assignee push, invitations, unlink behavior |
| D04 | Telemetry source and API extension placement | Optional telemetry/webhook/extension implementation |
| D05 | Object counts, baseline snapshots, and output attribution | Changes to counting, productivity, quality denominators |
| D06 | Time, provenance, and missing-data semantics | New time-based metrics and their UI/API contracts |

## D01 — CVAT hierarchy and tenant identity

**Evidence:** [baseline S2–S4](baseline.md). The PM branch maps CVAT Organization → VanoHub Project and CVAT Project → Dataset. The issue-logger specification maps CVAT Project → VanoHub Project with local Dataset grouping.

**Recommendation:** preserve the active accepted local model during structural refactoring. If organization-based tenancy is the chosen target, treat it as a data and authorization migration with an explicit conversion plan.

Before accepting, record:

- Canonical entity names, external identifiers, uniqueness scope, and tenant boundary.
- Whether organizations, personal workspaces, or multiple CVAT instances are supported.
- Which existing Project/Dataset/Batch rows map to the target; how ambiguous or duplicate external IDs are handled.
- API path/query meanings, authorization implications, and frontend label changes.
- Whether existing links, saved filters, audit references, and deliveries remain valid.

Do not equate changing the UI label “Project” with changing the identity or security scope of the Project model. Do not use one ambiguous `project_id` for both VanoHub and CVAT IDs without a documented boundary.

**Acceptance:** one mapping table in the current product/architecture documentation; affected contracts updated; migration checks and tenant-isolation scenarios identified.

## D02 — QC transition and sampling

**Evidence:** [baseline S2–S4](baseline.md). The reference product specification requires QC1 success to become `qc1_passed`, followed by PM confirmation of the eligible batch into QC2. Another branch's sync maps CVAT validation completion/acceptance to `pending_qc2`.

**Recommendation:** retain the current accepted PM confirmation gate unless a product decision explicitly changes it. Resolve sampling separately: job sampling and frame sampling have different populations, denominators, and review UI.

Record the transition table, actor capability, batch preconditions, interaction with locks/escalation, and handling of concurrent sync. Identify the authoritative stage/state separately from CVAT's native stage/state.

**Acceptance:** the backend transition, UI label/action, notifications, audit record, and API response describe the same event. Include tests for ineligible batches, four-eyes conflicts, and sync attempts after QC2/approval/delivery.

## D03 — Identity linking and outward CVAT writes

**Evidence:** [baseline S3–S5](baseline.md). One branch uses linked numeric CVAT account references and implements assignee push/invitations; another uses username-oriented lookup and one-way sync.

**Recommendation:** choose the identity model and write policy explicitly. Preserve already accepted functionality; do not enable invitation or assignment side effects merely by importing a helper from another branch.

Record:

- External user identity and its CVAT instance/organization scope; migration from username references and handling of renamed/unlinked accounts.
- Service identity versus user-delegated operations; credential storage, redaction, and minimum access.
- Allowed outbound operations, their initiating VanoHub actor, and their audit trail.
- Source of truth for assignment conflicts; behavior on unlink, revocation, missing membership, or partial failure.
- Whether retries are synchronous, scheduled, or durably queued. A post-commit callback alone is not a queue.

**Acceptance:** contract and UI expose the actual outcome; remote failure does not masquerade as success. Rollback notes account for remote assignments or invitations that a code revert cannot undo.

## D04 — Telemetry source and extension placement

**Evidence:** [baseline S2](baseline.md), PV04 and backlog B1–B5. The reference architecture does not fork or patch CVAT. The discussion also considered a CVAT-native extension and a separate GET gateway.

**Planning boundary:** VanoHub consumes CVAT data through APIs. Direct CVAT PostgreSQL/NAS access is outside scope. No direct ClickHouse connection is added by this plan.

| Candidate | Evaluate when | Required decision |
| --- | --- | --- |
| Existing supported CVAT API/export → VanoHub adapter | It exposes the required signals at acceptable freshness | Pin the deployed version, actual operation/schema, processing semantics, and limits |
| A native CVAT API extension | A demonstrated gap remains and modifying the CVAT deployment is acceptable | Reconcile no-patch policy, ownership, upgrade testing, schema registration, authorization, and resource limits |
| A separate API gateway for missing telemetry | A real trust/deployment boundary or reusable consumer need justifies it | Define narrow operations, service ownership, authentication, object scope, capacity, and failure handling |

A gateway is not automatically secure because it accepts only GET. Each operation still needs authorization and bounded input. Keep arbitrary SQL and raw database-table access out of public contracts. Keep Vector out of the application query path.

Extending “API docs” has two meanings: documenting existing routes or implementing a new route and documenting it. Record which is intended. Django's presence does not establish that an OpenAPI generator or docs UI is already configured.

**Acceptance:** name the requirement that existing APIs cannot satisfy, the selected source, hosting/maintenance owner, and contract. Do not implement all historical proposed endpoints by default.

## D05 — Counting, snapshots, and attribution

**Evidence:** [baseline S2 and S4](baseline.md). The pre-label section is marked as a proposal, including baseline S0, current S1, credited output, and daily recognition choices.

**Recommendation:** maintain separate definitions for visible object-frames, credited production, and the checked quality population. Do not replace them with a shape/track row count or a count of user interactions.

Before changing behavior, settle:

- Valid frame selection, frame numbering, step, deleted/included frames, outside intervals, and sparse tracks for the deployed CVAT version.
- Baseline capture timing; treatment of pre-labels, splits/merges, reassignment, rework, partial completion, and repeated imports/submits.
- The still-proposed per-frame credited-output formula `max(visible_S1, visible_S0)`; do not silently make it an implemented rule.
- Quality denominator and missing-object treatment under the existing specification; credited output is not a substitute for checked-object counts.
- Whether aggregate counts are enough or full immutable annotation/meta snapshots are needed for reproducible QC.

Aggregate baseline counts cannot reconstruct original geometry. A checksum is not itself an immutable snapshot. When several upstream reads form a snapshot, record its consistency rule and version evidence; do not claim atomic consistency across CVAT state and asynchronously ingested events.

**Acceptance:** examples with expected results, safe attribution to the correct worker/round, retry/deduplication behavior, and migration treatment for records without an original baseline.

## D06 — Time and metric semantics

**Evidence:** [baseline S2](baseline.md), NS01–NS09. Existing/proposed metrics mix provisional workflow timing with possible activity signals.

**Recommendation:** retain clear provenance. An elapsed workflow interval, a browser activity signal, and a verified business event represent different things.

Record timestamp format, duration unit, aggregation window, project display timezone, workday cutoff, actor mapping, cross-midnight behavior, duplicate/overlapping sessions, late events, and missing coverage. A workday cutoff is a separate business decision from timezone selection.

Do not assume upstream duration units. Normalize them explicitly. Do not silently substitute zero for unknown activity or calculate a rate from unavailable/zero denominators.

For QA/annotation ratios, choose comparable numerator and denominator semantics. An elapsed QA interval divided by active annotation time needs an explicit label and justification; it must not be presented as a comparable work-effort ratio by default.

**Acceptance:** the API and Vietnamese UI distinguish estimated, unavailable, and observed values using an agreed representation, with the same time window and units.

## Recording resolution

For each accepted or superseded record, append:

~~~text
Status and date:
Selected option and reason:
Authority/evidence: current spec, user decision, or accepted local ADR
Affected code, data, API, and UI:
Migration/compatibility and external effects:
Verification required and evidence:
Supersedes / superseded by:
~~~

Updating a record does not update the application. Link its implementation task and completed change entry.
