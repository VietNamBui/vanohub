# VanoHub implementation and documentation plan

Prepared: 2026-11-27, Asia/Ho_Chi_Minh.

**Goal:** finish the ongoing VanoHub refactor with coherent CVAT mapping, reliable workflow behavior, matching backend/frontend contracts, and enough documentation to resume work without replaying the conversation.

**Starting position:** the user reports that most of the codebase is indexed by codebase-memory-mcp and that a local agent is already refactoring. The reported configuration is Neon Extra High as orchestrator and Hydrogen Extra High as executor. This package does not inspect that live worktree or establish which application tasks are already complete.

**Operating default:** one orchestrator and one executor. Preserve completed work, retrieve narrow context, and document logical changes. Model labels do not imply a measured token saving.

## 1. Scope and constraints

- Consume CVAT annotation and operational data through its API. VanoHub must not read CVAT PostgreSQL or NAS directly. VanoHub's own database remains its normal persistence layer.
- Keep CVAT responsible for annotation data; keep VanoHub responsible for its business workflow, QC decisions, assignments, audit history, and delivery.
- Preserve the four-role model, project isolation, four-eyes rules, and protection of QC2/approved/delivered states unless a specific product change is accepted.
- Reuse `docs/platform-spec.md`, `docs/mvp-checklist.md`, `ARCHITECTURE.md`, `AGENTS.md`, and scoped rules. Record conflicts instead of silently choosing a historical branch.
- Keep new telemetry, webhook, native CVAT extension, and sidecar work conditional on an actual requirement. Documentation alone does not create an endpoint.
- Distinguish structural refactoring from changes to behavior, permissions, data models, API payloads, or UI semantics.

See [baseline](baseline.md) for evidence and [decisions](decisions.md) for unresolved choices.

## 2. Work plan

All application tasks start as **planned / local status unknown**. T00 may mark an item implemented or closed when current evidence supports it; it must not repeat work just to follow this sequence.

| ID | Outcome and work | Dependency | Owner | Acceptance evidence |
| --- | --- | --- | --- | --- |
| T00 | Capture the active checkout, local diff, relevant index coverage, deployed CVAT version, and existing documentation/schema tooling. Reconcile this package with ongoing work. | None | Executor gathers; orchestrator reconciles | Branch, HEAD, dirty-path summary, relevant source references, index identity/freshness evidence or unknown, and the next bounded task |
| T01 | Resolve affected CVAT mapping, QC2 transition/sampling, identity, and outbound-write decisions. Include D04/D06 for telemetry or new time metrics, and D05 when counting/attribution changes. | T00 | Orchestrator; executor provides evidence | Affected decision records accepted with migration/compatibility consequences, or only the affected work marked blocked |
| T02 | Establish a runnable baseline and fix confirmed blockers in the affected area. Treat old checklist findings as hypotheses until reproduced. | T00 | Executor | Exact baseline checks and outcomes; failures classified as pre-existing or introduced where evidence permits |
| T03 | Inventory the effective API and consumers; establish one reproducible OpenAPI workflow if none exists; specify proposed changes before dependent work. | T00, T02; T01 for disputed surfaces | Orchestrator owns semantic decisions; executor owns schema implementation | Current contract identified by revision, changed operations and consumers listed, compatibility decision and examples recorded |
| T04 | Consolidate and refactor backend/CVAT integration in bounded slices. Preserve agreed semantics while improving boundaries and error handling. | Affected T01 decisions and affected T03 contracts | Executor | Focused diff, relevant regression evidence, migrations when needed, no unresolved cross-project or workflow changes |
| T05 | Bring UI behavior into parity with accepted contracts, role capabilities, and workflow labels. Work screen by screen. | Stable affected T03 contracts; T04 for integration checks | Executor; separate UI writer only for independent files | [UI checklist](../ui/verification.md) completed for affected roles/states; contract and actual response parity |
| T06 | Apply and verify transport/environment rules for the real deployment topology. | T00; T01 if write or trust boundaries change | Executor | [Security checks](../operations/security-and-verification.md), correct proxy behavior, secret redaction, and upstream TLS verification |
| T07 | Integrate the changed slices and run the repository's required gates plus risk-focused scenarios. Repeat on the final integrated revision after any included T08 work. | Affected T04/T05/T06 work and any included T08 implementation | Executor runs; orchestrator reviews | Exact commands/results tied to the final revision and environment; UI, API, and database evidence as applicable |
| T08 | Implement a justified telemetry/webhook/API extension only after selecting its data source, semantics, and contract. | Accepted D04 and D06 via T01; D05 if counts/attribution change; affected T03 contracts; stable core workflow | Orchestrator scopes; executor implements | Accepted contract, authorization, replay/idempotency behavior, missing-data semantics, and integration evidence |
| T09 | Close the milestone and hand over the next bounded task. | Required scope passes T07 on the final revision, including T08 if selected | Orchestrator | Updated current docs, change entry, disclosed remaining out-of-scope work, and concise next handoff |

T08 is not a prerequisite for releasing the core refactor unless an accepted product requirement makes it one. Avoid introducing a queue, broker, new service, or new database simply to satisfy a proposed diagram.

## 3. T00: adopt the active work, once

Capture the worktree identity using read-only commands from its root:

~~~bash
git rev-parse --show-toplevel
git branch --show-current
git rev-parse HEAD
git status --short
git diff --stat
git diff --cached --stat
~~~

Inspect relevant untracked files as well as staged and unstaged diffs. These commands do not establish index freshness by themselves. Use the installed MCP server's actual tool schema to inspect the indexed project/root and available revision, coverage, watcher, or freshness information. If this is unavailable, record unknown and validate the specific current files before relying on graph results.

Read existing local instructions before applying any advice in this package. Do not reset, stash, rebase, or discard another agent's work as part of adoption. If parallel implementation is useful, use isolated worktrees with explicit ownership and confirm each index targets the correct worktree.

Add the local record to [baseline.md](baseline.md). Update task status from evidence. Keep historical source observations intact and clearly dated.

## 4. T01: decisions that change the implementation

The remote evidence contains two incompatible mappings:

- `feature/project-manager`: CVAT Organization → VanoHub Project; CVAT Project → Dataset.
- `feature/issue-logger` and its product specification: CVAT Project → VanoHub Project; Dataset is a local grouping.

It also contains different transitions from CVAT validation/acceptance into VanoHub QC2. These are product and data decisions, not naming cleanups. Resolve the affected records in [decisions.md](decisions.md) before changing migrations, API identifiers, navigation, or status labels.

The orchestrator can resolve routine implementation choices. Ask the user only when a genuinely unresolved product choice would change behavior or invalidate existing data; prepare the alternatives and consequences first. Continue unrelated work.

## 5. T03–T05: contract-led implementation slices

For each slice, identify the source revision and state the intended behavior:

1. Capture current inputs, outputs, permissions, state changes, and actual consumers.
2. Describe the proposed change and whether existing consumers continue to work.
3. Implement the smallest coherent backend slice, including any necessary migration.
4. Update affected frontend types, API wrappers, guards, forms, and Vietnamese labels.
5. Verify the relevant behavior, then satisfy the repository's required task-completion gates.
6. Record one entry in [changes.md](changes.md) and update the relevant current document.

Use a stable contract to enable independent backend/UI work. Assign one writer to shared serializers, schema output, migrations, role definitions, and the plan's active handoff. Do not merge entire historical branches merely because one contains a useful implementation.

### Backend focus for T04

- Fetch and validate remote data outside long database transactions; recheck mutable local preconditions under the appropriate lock before applying a result.
- Preserve validated CVAT payload handling, bounded request behavior, and project/job ownership checks.
- Distinguish current visible object-frame counts, credited output, and quality denominators. Validate track/frame edge cases against the deployed CVAT version.
- Keep remote writes explicit. A post-commit callback is not a durable background job.
- Specify retry, stale-data, partially missing-job, and source-deleted behavior. Do not claim incremental sync correctness from an unverified timestamp filter.
- Attribute audit actions to the correct actor/source. Avoid interpreting a PM-triggered sync as proof that the PM performed annotation or QC.

### UI focus for T05

Prioritize the existing import/sync, assignment/claim, QC1, PM confirmation, QC2 audit, and delivery flows. Reuse the active design system. If an Ant Design-to-Untitled UI migration is part of the local task, migrate a coherent screen and keep behavior/contract checks separate from visual changes.

## 6. Conditional telemetry and API work

T08 starts with a capability check against the deployed CVAT version and accepted architecture. Compare supported API/export ingestion, an explicit extension hosted with CVAT, and an external API gateway only when a real gap remains.

The current reference specification says no CVAT fork/patch. A native CVAT extension therefore needs that architecture decision updated before it becomes the chosen implementation. Direct CVAT PostgreSQL/NAS access remains outside the stated boundary; direct ClickHouse access is not implicitly authorized by this plan.

Keep best-effort activity signals separate from immutable QC snapshots and business audit records. Publish metric provenance and missing-data states; do not present elapsed workflow time as measured active time.

## 7. Definition of completion

A milestone is complete when its accepted scope is implemented, its affected contract and UI agree, applicable required gates pass on the final integrated revision, and relevant documentation reflects the result. A documented exception counts only when the existing repository policy permits it. Keep implemented work with failed, blocked, or unrun required gates open and report that verification status. An unfinished optional telemetry task does not block unrelated core work when it is outside the accepted milestone scope.

For schema changes, include migration/roll-forward evidence and distinguish database rollback from code rollback. For remote writes, explain any persistent external effects. Do not imply that reverting a commit reverses invitations, assignments, notifications, or data migrations.

## 8. Active handoff

| Field | Initial value |
| --- | --- |
| Task | T00 — adopt current local refactor and choose the next bounded task |
| Worktree / revision | Not captured in this documentation session |
| Files owned | Local baseline and task status; inspect existing edits before assigning implementation files |
| Established evidence | [Remote baseline](baseline.md), existing local instructions, and this package |
| Checks / outcomes | Package verification reported in the delivery README; application checks not run here |
| Next action / blocker | Capture local state; determine which historical conflicts are still relevant |

Replace this handoff when the active task changes. Preserve only durable outcomes in the change log.
