# Evidence baseline

Captured: 2026-11-27, Asia/Ho_Chi_Minh. Repository: [VietNamBui/vanohub](https://github.com/VietNamBui/vanohub).

## 1. Evidence boundaries

This package used the conversation, the attached conversation log, and read-only GitHub inspection. The branch list and selected source files were refreshed during preparation. No connection to the user's active local checkout, deployed CVAT, or local codebase-memory-mcp server was available.

The attached log contains evolving recommendations and some branch attribution errors. Treat it as design history. Use the pinned source below for remote implementation claims, and T00 for current local claims. In particular, do not carry forward a statement that the repository is only a scaffold, that every branch has the latest PM changes, or that a proposed telemetry service already exists.

## 2. Remote revisions

| Branch | Observed HEAD |
| --- | --- |
| `main` | `3e21fa11e9250b28af7a9b75e23b63c54ffe2da5` |
| `feature/project-manager` | `24ca99c728c97d924b97c5a913533cfba36bee3b` |
| `annotator-qclv1` | `25bd5f2f998152c4daf4dcc387063af8e7bade44` |
| `feature/issue-logger` | `99027769c86536807d31808ff666e9a424505aea` |

These are snapshots, not a recommended merge base. No automatic branch merge or application migration is part of this documentation package.

## 3. Observations that affect the plan

| Area | Source observation | Meaning for the refactor | Verification |
| --- | --- | --- | --- |
| Entity mapping | PM sync maps CVAT Organization → Project and CVAT Project → Dataset; issue-logger's specification maps CVAT Project → Project | Resolve D01 before schema, route, or UI naming changes | Source inspected [S2], [S3]; no runtime check |
| QC transition | PM sync maps validation complete/acceptance into `PENDING_QC2`; issue-logger caps those at `QC1_PASSED` and preserves PM confirmation | Resolve D02; do not silently substitute states | Source inspected [S3], [S4] |
| Identity and remote writes | PM branch has linked CVAT account references and code to push assignees and invite organization members | Decide identity migration and allowed write scope; this is not a uniformly GET-only integration | Source inspected [S3], [S5] |
| Scheduling | PM assignee push is registered with `transaction.on_commit` | Running after commit does not by itself provide durable queueing, retries, or worker isolation | Source inspected [S5] |
| Current HTTP surfaces | Issue-logger registers `/api/cvat/status/` and `/api/cvat/tasks/` | Use these as branch-specific observations, not as the whole platform API | Source inspected [S6], [S7] |
| API documentation tooling | Inspected URL configuration has no schema/docs registration; inspected Pipfile has no named schema-generator dependency | T00 must check the local branch before choosing or adding tooling | Source inspected [S6], [S8]; not an exhaustive dependency/runtime audit |
| Product boundary | Reference spec says original CVAT without fork/patch and VanoHub-owned business workflow | Preserve the boundary while resolving proposed extensions explicitly | Spec [S2] |
| Telemetry | Spec marks plugin hooks, telemetry events, ingestion, and webhook endpoints as backlog | Candidate contracts must remain proposals until implemented | Spec [S2], backlog B1–B5 |
| Productivity | NS01/NS03 are provisional; NS04 and NS09 contain unresolved definitions | Preserve provenance and unknown values; telemetry does not automatically settle semantics | Spec [S2], NS rows |
| Existing operating rules | Root instructions link scoped rules and CI gates; UI copy remains Vietnamese | Extend those instructions through links and targeted additions | [S1], [S9] |

The existing `docs/mvp-checklist.md` includes statements about an older commit plus uncommitted local changes, numerical progress estimates, and claimed failures. Those are historical reports. This package does not claim that those failures or percentages describe the present local refactor.

## 4. User requirements and planning defaults

| Item | Classification | Treatment |
| --- | --- | --- |
| Local refactor already underway | User-reported | Resume it; capture local evidence before changing status |
| Most code indexed in codebase-memory-mcp | User-reported | Reuse relevant index results; validate freshness and root |
| Neon Extra High orchestrator / Hydrogen Extra High executor | User-reported configuration | Keep a small two-role workflow; no capability or cost claims |
| Avoid unnecessary token use | User objective | Compact handoffs, narrow retrieval, reuse evidence, no tool-by-tool diary |
| Document refactor, UI, and API changes | Requested deliverable | One logical change record per reviewable unit |
| CVAT API boundary; no direct CVAT PostgreSQL/NAS reads | User constraint from the discussion | Carry into implementation scope |
| API-mediated telemetry as the initial design boundary | Conservative planning default | Resolve D04 before introducing a new data connection or service |

## 5. Local baseline record — fill in during T00

| Field | Value |
| --- | --- |
| Repository root / worktree | Not captured |
| Branch / HEAD | Not captured |
| Relevant staged, unstaged, and untracked changes | Not captured |
| Current instruction files and accepted local decisions | Not captured |
| MCP implementation/version and indexed project/root | Not inspected |
| Index freshness or revision evidence | Unknown; do not infer from “mostly indexed” |
| Deployed CVAT version and schema source | Not inspected; earlier notes refer to more than one version |
| Existing OpenAPI artifact and generator | Local state not inspected |
| Current baseline checks and environment | Not run |
| Tasks already completed locally | To reconcile from actual evidence |

Record source paths and revisions rather than pasting entire files. Preserve this remote baseline when adding a newer local baseline.

## 6. Pinned sources

- [S1: existing AGENTS.md](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/AGENTS.md)
- [S2: platform specification](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/docs/platform-spec.md)
- [S3: PM branch CVAT sync](https://github.com/VietNamBui/vanohub/blob/24ca99c728c97d924b97c5a913533cfba36bee3b/backend/cvat_integration/sync.py)
- [S4: issue-logger CVAT sync](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/backend/cvat_integration/sync.py)
- [S5: PM assignee and invitation behavior](https://github.com/VietNamBui/vanohub/blob/24ca99c728c97d924b97c5a913533cfba36bee3b/backend/cvat_integration/assignee.py)
- [S6: platform URL configuration](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/backend/config/urls.py)
- [S7: CVAT integration URLs](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/backend/cvat_integration/urls.py) and [views](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/backend/cvat_integration/views.py)
- [S8: backend dependency declaration](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/backend/Pipfile)
- [S9: CI workflow](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/.github/workflows/ci.yml), [domain rules](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/.agents/rules/domain-invariants.md), and [frontend rules](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/.agents/rules/frontend.md)
- [S10: historical MVP checklist](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/docs/mvp-checklist.md)

External implementation references belong near the relevant guidance, such as the [security document](../operations/security-and-verification.md). This source list establishes what was read; it does not certify the application.
