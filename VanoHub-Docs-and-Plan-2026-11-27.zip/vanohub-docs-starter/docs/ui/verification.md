# UI change and verification guide

Prepared: 2026-11-27. Use for T05 and affected T07 checks. This guide extends the active frontend rules; it does not replace the product specification or redesign every screen.

## 1. Define a screen-sized change

Before implementation, record the route/screen, affected roles, intended interaction, API contract ID, and the baseline revision or screenshot. Describe observable before/after behavior separately from component restructuring.

Reuse the active design system and feature boundaries. If migrating a screen from Ant Design to Untitled UI, preserve its accepted behavior while checking form, focus, validation, keyboard, and async-state behavior. Avoid a simultaneous whole-application redesign.

The reference [frontend rules](https://github.com/VietNamBui/vanohub/blob/99027769c86536807d31808ff666e9a424505aea/.agents/rules/frontend.md) require Vietnamese UI copy, shared API handling, capability parity, and appropriate entity-keyed state. Confirm newer local rules during T00.

## 2. Role and workflow coverage

| Role/surface | Main scenario | Negative or boundary scenario |
| --- | --- | --- |
| PM | Import/sync, assign, configure the permitted workflow, confirm eligible batch to QC2, close audit, deliver | Ineligible batch, missing source, unauthorized project, locked/delivered job, failed remote action |
| Annotator | Claim/start/open CVAT, submit, inspect rework | WIP limit, concurrent claim, wrong assignee, stale job state, pending count if supported |
| QC1 | Open assigned work, record positioned errors, pass or reject | Self-review/four-eyes conflict, missing required fields, duplicate submit, stale status |
| QC2 | Open eligible sample, record review, complete allowed audit step | Historical four-eyes conflict, wrong project/sample, incomplete prerequisites |
| Multi-role user | Switch project and permitted role context | State/data retained from another project, incorrect implied role, stale capability cache |
| Analytics | Read metric value, units, window and provenance; drill down | Unknown/estimated data shown as zero, denominator missing, filter/window lost in navigation |

Use only scenarios touched by the slice, then cover the required end-to-end path at the milestone boundary. Do not invent available routes or actions for features still marked as proposals.

## 3. Per-screen checklist

- [ ] Route guard matches the relevant backend capability; backend authorization remains authoritative.
- [ ] API wrapper, request fields, response types, errors, and status enums match the accepted contract.
- [ ] Vietnamese labels reflect the actual transition: for example, “Đạt QC1” and “Chờ QC2” are not interchangeable.
- [ ] Loading, empty, error, retry, permission-denied, and stale-data states are handled where applicable.
- [ ] Mutations prevent accidental double submission and show actual server outcomes.
- [ ] Switching project/entity resets the correct form, selection, modal, and query state.
- [ ] Row actions, filters, URL parameters, and drill-down links preserve intended context.
- [ ] Dates and workday boundaries use the accepted project timezone/cutoff, not an incidental browser timezone.
- [ ] Metric labels distinguish estimates, unavailable values, and observed data; units and denominators are visible when needed.
- [ ] Relevant keyboard/focus behavior, form labels/errors, and the actual target viewport are checked.
- [ ] No credentials, private upstream payloads, or unauthorized project details appear in the UI or browser bundle.

For QC forms, check the locally accepted handling of frame/object identifiers, verdict, missing-object flags, and voided errors. The old checklist's claims of missing fields are investigation leads; reproduce them before treating them as present defects.

## 4. Evidence format

Use one concise table per changed screen or coherent group:

| Route / role / state | Action and expected result | Actual result | Evidence / revision |
| --- | --- | --- | --- |
| Fill from the local implementation | Include the relevant API interaction | Passed / failed / not run, with reason | Screenshot or test/log reference and exact revision |

If the screen cannot be exercised, state the missing dependency. A successful TypeScript build does not establish browser behavior.

Attach before/after screenshots when visual changes need comparison; exclude credentials and personal data. Retain only useful evidence rather than a screenshot of every click.

## 5. Completion

Update [changes.md](../refactoring/changes.md) with the screen, interaction change, contract impact, actual checks, and remaining issues. Update the existing product checklist only when its status is supported. Keep detailed product behavior in the existing specification and detailed API shapes in the canonical contract.

Relevant tasks and dependencies: [plan.md](../refactoring/plan.md). Contract procedure: [contracts.md](../api/contracts.md).
